const db = require("../config/db-config");
const bcrypt = require("bcryptjs");

const chatbot = async (req, res) => {
  const { query } = req.body;

  // Check if a query is provided
  if (!query) {
    return res.json({
      status: "error",
      error: "Please provide a query.",
    });
  }

  try {
    // Query your database to retrieve a response based on the user's query
    db.query(
      "SELECT response FROM chatbot WHERE user_query = ?",
      [query],
      (err, result) => {
        if (err) {
          return res.json({
            status: "error",
            error: "An error occurred while processing your query. Please try again later.",
          });
        }

        if (result.length === 0) {
          return res.json({
            status: "success",
            response: "I'm sorry, I don't have an answer for that query.",
          });
        }

        const response = result[0].response;

        // Save the conversation in the database
        db.query(
          "INSERT INTO chatbot_conversations (user_query, chatbot_response) VALUES (?, ?)",
          [query, response],
          (err) => {
            if (err) {
              console.error(err);
              return res.json({
                status: "error",
                error: "An error occurred while saving the conversation.",
              });
            }

            return res.json({
              status: "success",
              response,
            });
          }
        );
      }
    );
  } catch (error) {
    console.error(error);
    return res.json({
      status: "error",
      error: "An error occurred during query processing. Please try again later.",
    });
  }
};

module.exports = chatbot;
