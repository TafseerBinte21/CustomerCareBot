const { json } = require("express");
const db = require("../config/db-config");
const bcrypt = require("bcryptjs");

const chatbot = async (req, res) => {
  const { query, userId } = req.body; // Assuming you have a userId in the request body

  // Check if a query is provided
  if (!query) {
    return res.json({
      status: "error",
      error: "Please provide a query.",
    });
  }

  try {
    // Query your database to retrieve a response based on the user's query
    db.query(
      "SELECT response FROM chatbot WHERE user_query = ?",
      [query],
      (err, result) => {
        if (err) {
          return res.json({
            status: "error",
            error: "An error occurred while processing your query. Please try again later.",
          });
        }

        if (result.length === 0) {
          return res.json({
            status: "success",
            response: "I'm sorry, I don't have an answer for that query.",
          });
        }

        const response = result[0].response;

        // Retrieve the user's existing conversation history
        db.query(
          "SELECT conversation FROM user WHERE id = ?",
          [userId],
          (err, userResult) => {
            if (err) {
              console.error(err);
              return res.json({
                status: "error",
                error: "An error occurred while retrieving the conversation history.",
              });
            }

           
            let conversation = [];

            if (userResult.length > 0 && userResult[0].conversation) {
              conversation = JSON.parse(userResult[0].conversation);
            }

            // Add the new query and chatbot response to the conversation
            conversation.push({
              userQuery: query,
              chatbotResponse: response,
            });
            

            // Update the user's conversation history in the database
            console.log(conversation)
            db.query(
              "UPDATE user SET conversation = ? WHERE id = ?",
              [JSON.stringify(conversation), userId],
              (err) => {
                if (err) {
                  console.error(err);
                  return res.json({
                    status: "error",
                    error: "An error occurred while updating the conversation history.",
                  });
                }

                return res.json({
                  status: "success",
                  response,
                });
              }
            );
          }
        );
      }
    );
  } catch (error) {
    console.error(error);
    return res.json({
      status: "error",
      error: "An error occurred during query processing. Please try again later.",
    });
  }
};

module.exports = chatbot;
