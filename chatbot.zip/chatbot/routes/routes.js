const express = require("express");
const router = express.Router();

const registerController = require("../controllers/register");
const loginController = require("../controllers/login");
const logoutController = require("../controllers/logout");
const isLoggedInController = require("../controllers/isLoggedIn");
const chatbotController = require("../controllers/chatbot");


router.get("/chat", isLoggedInController, (req, res) => {
    if (req.user) {
        res.render("chat", { user: req.user, role: req.role });
    } else if (req.admin) {
        res.render("chat", { user: req.admin, role: req.role });
    } else if (req.counselor) {
        res.render("chat", { user: req.counselor, role: req.role });
    } else {
        res.render("index");
    }
});

// Define a route for the chatbot
router.post("/chat", chatbotController);

router.get("/", isLoggedInController, (req, res) => {
    if (req.user) {
        res.render("robibusiness", { user: req.user, role: req.role });
    } else if (req.admin) {
        res.render("robibusiness", { user: req.admin, role: req.role });
    } else if (req.counselor) {
        res.render("robibusiness", { user: req.counselor, role: req.role });
    } else {
        res.render("index");
    }
});

router.get("/register", isLoggedInController, (req, res) => {
    if (req.user || req.admin || req.counselor) {
        res.redirect("/");
    } else {
        res.render("register");
    }
});

router.post("/register", registerController);

router.get("/login", isLoggedInController, (req, res) => {
    if (req.user || req.admin || req.counselor) {
        res.redirect("/");
    } else {
        res.render("login");
    }
});

router.post("/login", loginController);

router.get("/success", isLoggedInController, (req, res) => {
    if (req.user) {
        res.render("success", { user: req.user, role: req.role });
    } else if (req.admin) {
        res.render("success", { user: req.admin, role: req.role });
    } else if (req.counselor) {
        res.render("success", { user: req.counselor, role: req.role });
    } else {
        res.render("index");
    }
});

// router.post("/adminlogin", adminloginController);

// router.get("/adminlogin", isLoggedInController, (req, res) => {
//     if (req.user || req.admin || req.counselor) {
//         res.redirect("/");
//     } else {
//         res.render("adminLogin");
//     }
// });




router.get('/', (req, res) => {
    res.render('index'); // This assumes your EJS file is named "index.ejs"
});






router.get("/logout", logoutController);
module.exports = router;
